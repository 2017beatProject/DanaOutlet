package com.bit.daNaOutlet.model;

import java.util.List;

public interface ClipDao {

	List<E> list() {}
	
}
